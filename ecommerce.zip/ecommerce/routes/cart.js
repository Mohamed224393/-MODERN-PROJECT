const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Cart = require('../models/Cart');
const Product = require('../models/Products'); // Added Product import

// Authentication middleware
const authMiddleware = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }
    try {
        const decoded = jwt.verify(token, process.env.secret || 'someverystrongsecretkey1234!');
        req.user = { _id: decoded.userId };
        next();
    } catch (err) {
        console.error('Token verification error:', err);
        res.status(401).json({ message: 'Invalid token' });
    }
};

router.use(authMiddleware);

// Get user's cart
router.get('/', async (req, res) => {
    try {
        const cart = await Cart.findOne({ userId: req.user._id }).populate('items.productId');
        if (!cart) {
            return res.status(404).json({ message: 'Cart not found' });
        }
        res.json(cart);
    } catch (err) {
        console.error('Error fetching cart:', err);
        res.status(500).json({ message: err.message });
    }
});

// Add item to cart
router.post('/add', async (req, res) => {
    try {
        const { productId, quantity } = req.body;
        console.log('POST /cart/add request:', { productId, quantity, userId: req.user._id });

        // Validate input
        if (!productId || !quantity || quantity < 1) {
            return res.status(400).json({ message: 'Invalid productId or quantity' });
        }

        // Check product
        const product = await Product.findById(productId);
        if (!product) {
            console.log('Product not found for ID:', productId);
            return res.status(404).json({ message: 'Product not found' });
        }
        if (product.stock < quantity) {
            console.log('Insufficient stock for product:', productId, 'Stock:', product.stock, 'Requested:', quantity);
            return res.status(400).json({ message: `Insufficient stock. Available: ${product.stock}` });
        }

        // Find or create cart
        let cart = await Cart.findOne({ userId: req.user._id });
        if (!cart) {
            cart = new Cart({
                userId: req.user._id,
                items: [],
                totalPrice: 0
            });
        }

        // Update cart items
        const itemIndex = cart.items.findIndex(item => item.productId.toString() === productId);
        if (itemIndex > -1) {
            cart.items[itemIndex].quantity += quantity;
        } else {
            cart.items.push({ productId, quantity });
        }

        // Calculate total price
        cart.totalPrice = await calculateTotalPrice(cart.items);
        const updatedCart = await cart.save();
        console.log('Cart updated:', updatedCart);
        res.json(updatedCart);
    } catch (err) {
        console.error('Error adding to cart:', err);
        res.status(400).json({ message: err.message });
    }
});

// Remove item from cart
router.delete('/remove/:productId', async (req, res) => {
    try {
        const cart = await Cart.findOne({ userId: req.user._id });
        if (!cart) {
            return res.status(404).json({ message: 'Cart not found' });
        }

        cart.items = cart.items.filter(item => item.productId.toString() !== req.params.productId);
        cart.totalPrice = await calculateTotalPrice(cart.items);
        const updatedCart = await cart.save();
        res.json(updatedCart);
    } catch (err) {
        console.error('Error removing from cart:', err);
        res.status(500).json({ message: err.message });
    }
});

// Update item quantity
router.patch('/update/:productId', async (req, res) => {
    try {
        const { quantity } = req.body;
        if (!quantity || quantity < 1) {
            return res.status(400).json({ message: 'Invalid quantity' });
        }

        const cart = await Cart.findOne({ userId: req.user._id });
        if (!cart) {
            return res.status(404).json({ message: 'Cart not found' });
        }

        const itemIndex = cart.items.findIndex(item => item.productId.toString() === req.params.productId);
        if (itemIndex === -1) {
            return res.status(404).json({ message: 'Item not found in cart' });
        }

        const product = await Product.findById(req.params.productId);
        if (!product) {
            return res.status(404).json({ message: 'Product not found' });
        }
        if (product.stock < quantity) {
            return res.status(400).json({ message: `Insufficient stock. Available: ${product.stock}` });
        }

        cart.items[itemIndex].quantity = quantity;
        cart.totalPrice = await calculateTotalPrice(cart.items);
        const updatedCart = await cart.save();
        res.json(updatedCart);
    } catch (err) {
        console.error('Error updating cart:', err);
        res.status(400).json({ message: err.message });
    }
});

// Calculate total price
async function calculateTotalPrice(items) {
    let total = 0;
    for (const item of items) {
        const product = await Product.findById(item.productId);
        if (!product) {
            throw new Error(`Product not found: ${item.productId}`);
        }
        total += product.price * item.quantity;
    }
    return total;
}

module.exports = router;