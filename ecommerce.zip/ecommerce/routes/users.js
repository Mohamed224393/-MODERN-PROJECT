const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const secret = process.env.secret || 'someverystrongsecretkey1234!';

// Register a new user
router.post('/register', async (req, res) => {
    try {
        const { firstName, lastName, email, password, phone, isAdmin } = req.body;

        // Check if user exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already exists' });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create user
        const user = new User({
            firstName,
            lastName,
            email,
            password: hashedPassword,
            phone,
            isAdmin: isAdmin || false // Default to false if not provided
        });

        const savedUser = await user.save();

        // Generate JWT
        const token = jwt.sign(
            { userId: savedUser._id, email: savedUser.email, isAdmin: savedUser.isAdmin },
            secret,
            { expiresIn: '1h' }
        );

        res.status(201).json({ token, user: { _id: savedUser._id, email: savedUser.email, isAdmin: savedUser.isAdmin } });
    } catch (err) {
        console.error('Registration error:', err);
        res.status(400).json({ message: err.message });
    }
});

// Login user
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        // Generate JWT
        const token = jwt.sign(
            { userId: user._id, email: user.email, isAdmin: user.isAdmin },
            secret,
            { expiresIn: '1h' }
        );

        res.json({ token, user: { _id: user._id, email: user.email, isAdmin: user.isAdmin } });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ message: err.message });
    }
});

// Get current user (for admin verification)
router.get('/me', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ message: 'No token provided' });
        }

        const decoded = jwt.verify(token, secret);
        const user = await User.findById(decoded.userId).select('email isAdmin');
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({ email: user.email, isAdmin: user.isAdmin });
    } catch (err) {
        console.error('Error in /users/me:', err);
        res.status(401).json({ message: 'Invalid token' });
    }
});

module.exports = router;