const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Order = require('../models/Order');
const OrderItem = require('../models/order-item');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Middleware to verify user (optional, kept for other routes)
const verifyUser = async (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ success: false, message: 'No token provided' });
    }
    try {
        if (!process.env.secret) {
            console.error('JWT secret not defined in .env');
            return res.status(500).json({ success: false, message: 'Server configuration error' });
        }
        console.log('Verifying token:', token.slice(0, 10) + '...');
        const decoded = jwt.verify(token, process.env.secret);
        console.log('Decoded token:', decoded);
        req.user = await User.findById(decoded.userId);
        if (!req.user) {
            return res.status(401).json({ success: false, message: 'Invalid user' });
        }
        next();
    } catch (err) {
        console.error('Token verification error:', err.message);
        res.status(401).json({ success: false, message: 'Invalid token' });
    }
};

// Create a new order (no authentication required)
router.post('/', async (req, res) => {
    try {
        const { shippingDetails, phone, orderItems, paymentMethod, email } = req.body;

        // Validate input
        if (!shippingDetails || !phone || !orderItems || !paymentMethod) {
            return res.status(400).json({ success: false, message: 'Missing required fields' });
        }

        // Optional: Associate with user if token provided
        let userId = null;
        const token = req.headers.authorization?.split(' ')[1];
        if (token) {
            try {
                const decoded = jwt.verify(token, process.env.secret);
                const user = await User.findById(decoded.userId);
                if (user) userId = user._id;
            } catch (err) {
                console.warn('Invalid token provided, proceeding as guest:', err.message);
            }
        }

        // Create order items
        const orderItemsIds = await Promise.all(
            orderItems.map(async (item) => {
                let newOrderItem = new OrderItem({
                    quantity: item.quantity,
                    product: item.product
                });
                newOrderItem = await newOrderItem.save();
                return newOrderItem._id;
            })
        );

        // Calculate total price
        const orderItemsResolved = await OrderItem.find({ _id: { $in: orderItemsIds } })
            .populate('product');
        const totalPrice = orderItemsResolved.reduce((total, item) => {
            return total + (item.quantity * item.product.price);
        }, 0);

        // Create order
        let order = new Order({
            user: userId, // Null for guest orders
            shippingDetails,
            phone,
            email, // Optional guest email
            orderItems: orderItemsIds,
            paymentMethod,
            totalPrice,
            status: 'pending'
        });

        order = await order.save();

        res.status(201).json({
            success: true,
            order: {
                id: order._id,
                shippingDetails,
                phone,
                email,
                orderItems: orderItemsIds,
                paymentMethod,
                totalPrice,
                status: order.status
            }
        });
    } catch (err) {
        console.error('Error creating order:', err);
        res.status(400).json({ success: false, message: err.message });
    }
});

module.exports = router;