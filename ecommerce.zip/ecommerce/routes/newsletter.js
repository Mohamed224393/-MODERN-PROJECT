const express = require('express');
const router = express.Router();
const Newsletter = require('../models/newsletter');

// Subscribe to newsletter
router.post('/subscribe', async (req, res) => {
    try {
        const { email } = req.body;
        const existingSubscription = await Newsletter.findOne({ email });
        if (existingSubscription) {
            return res.status(400).json({ message: 'Email already subscribed' });
        }

        const subscription = new Newsletter({ email });
        const newSubscription = await subscription.save();
        res.status(201).json(newSubscription);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

module.exports = router;