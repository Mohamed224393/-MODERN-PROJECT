const express = require('express');
const router = express.Router();

// Handle contact form submission
router.post('/submit', async (req, res) => {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    // TODO: Save to database or send email (e.g., using nodemailer)
    console.log('Contact form submission:', { name, email, subject, message });

    res.status(200).json({ message: 'Message received successfully' });
});

module.exports = router;