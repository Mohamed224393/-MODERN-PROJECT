const express = require('express');
const router = express.Router();
const Product = require('../models/Products');

// Get new arrivals
router.get('/new-arrivals', async (req, res) => {
    try {
        const { page = 1, limit = 12 } = req.query; // Increased default limit to 12
        const products = await Product.find()
            .sort({ createdAt: -1 }) // Newest first
            .skip((page - 1) * parseInt(limit))
            .limit(parseInt(limit));
        console.log(`Returning ${products.length} new arrivals, page: ${page}, limit: ${limit}`);
        res.json(products);
    } catch (err) {
        console.error('Error fetching new arrivals:', err);
        res.status(500).json({ message: err.message });
    }
});

// Other routes (assumed unchanged)
router.get('/featured', async (req, res) => {
    try {
        const { page = 1, limit = 8 } = req.query;
        const products = await Product.find({ featured: true })
            .skip((page - 1) * parseInt(limit))
            .limit(parseInt(limit));
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/', async (req, res) => {
    try {
        const { page = 1, limit = 16, category } = req.query;
        const query = category ? { category } : {};
        const products = await Product.find(query)
            .skip((page - 1) * parseInt(limit))
            .limit(parseInt(limit));
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });
        res.json(product);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/', async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.status(201).json(product);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

router.patch('/:id', async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!product) return res.status(404).json({ message: 'Product not found' });
        res.json(product);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });
        res.json({ message: 'Product deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;