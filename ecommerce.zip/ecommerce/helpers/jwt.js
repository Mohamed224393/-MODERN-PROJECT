const { expressjwt: expressJwt } = require('express-jwt');

function authJwt() {
    const secret = process.env.JWT_SECRET || 'yourFallbackSecret'; // Use JWT_SECRET
    const api = process.env.API_URL || '/api/v1';

    const publicRoutes = [
        { url: /\/public\/uploads(.*)/, methods: ['GET', 'OPTIONS'] },
        { url: /\/api\/v1\/products(.*)/, methods: ['GET', 'OPTIONS'] },
        { url: /\/api\/v1\/categories(.*)/, methods: ['GET', 'OPTIONS'] },
        { url: /\/api\/v1\/orders(.*)/, methods: ['GET', 'OPTIONS', 'POST'] }, // POST is public
        `${api}/users/login`,
        `${api}/users/register`,
    ];

    return expressJwt({
        secret,
        algorithms: ['HS256'],
        isRevoked: isRevoked
    }).unless({
        path: publicRoutes
    });
}

async function isRevoked(req, token) {
    // Skip revocation for public routes (e.g., POST /api/v1/orders)
    if (req.method === 'POST' && req.path.match(/\/api\/v1\/orders/)) {
        return false; // Allow all users for POST /orders
    }
    // Only allow access if the user is an admin for protected routes
    if (!token.payload.isAdmin) {
        console.log('Access denied. Token revoked for non-admin user:', token.payload);
        return true; // Revoke token for non-admin
    }
    return false; // Allow admin
}

module.exports = authJwt;