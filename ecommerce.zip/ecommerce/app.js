const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

// Initialize app
const app = express();
const api = process.env.API_URL || '/api/v1';

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use(`${api}/products`, require('./routes/products'));
app.use(`${api}/categories`, require('./routes/categories'));
app.use(`${api}/users`, require('./routes/users'));
app.use(`${api}/cart`, require('./routes/cart'));
app.use(`${api}/contact`, require('./routes/contact'));
app.use(`${api}/orders`, require('./routes/orders')); // Fixed path to /orders

// MongoDB connection
mongoose.connect(process.env.CONNECTION_STRING, {
    serverSelectionTimeoutMS: 5000
})
.then(() => {
    console.log('MongoDB connected successfully');
})
.catch(err => {
    console.error('MongoDB connection error:', err.message);
});

// Log connection state
mongoose.connection.on('error', err => {
    console.error('Mongoose error:', err.message);
});
mongoose.connection.on('connected', () => {
    console.log('Mongoose connected to MongoDB');
});
mongoose.connection.on('disconnected', () => {
    console.warn('Mongoose disconnected');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running http://localhost:${PORT}`);
    console.log('API base path:', api);
});