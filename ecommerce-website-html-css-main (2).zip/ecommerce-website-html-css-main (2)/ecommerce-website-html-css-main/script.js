const API_BASE_URL = 'http://localhost:3000/api/v1';

// Utility function for GET requests
async function get(url) {
    const token = localStorage.getItem('jwtToken');
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    
    const response = await fetch(`${API_BASE_URL}${url}`, {
        method: 'GET',
        headers
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`GET ${url} failed: ${response.status} ${response.statusText}\nResponse: ${text}`);
        throw new Error(`GET ${url} failed: ${response.status}`);
    }
    return response.json();
}

// Utility function for POST requests
async function post(url, data) {
    const token = localStorage.getItem('jwtToken');
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    
    console.log(`Sending POST to ${url} with token: ${token ? token.slice(0, 10) + '...' : 'none'}`);
    const response = await fetch(`${API_BASE_URL}${url}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(data)
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`POST ${url} failed: ${response.status} ${response.statusText}\nResponse: ${text}`);
        throw new Error(`POST ${url} failed: ${response.status}`);
    }
    return response.json();
}

// Utility function for DELETE requests
async function del(url) {
    const token = localStorage.getItem('jwtToken');
    const headers = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    
    const response = await fetch(`${API_BASE_URL}${url}`, {
        method: 'DELETE',
        headers
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`DELETE ${url} failed: ${response.status} ${response.statusText}\nResponse: ${text}`);
        throw new Error(`DELETE ${url} failed: ${response.status}`);
    }
    return response.json();
}

// Utility function for PATCH requests
async function patch(url, data) {
    const token = localStorage.getItem('jwtToken');
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    
    const response = await fetch(`${API_BASE_URL}${url}`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify(data)
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`PATCH ${url} failed: ${response.status} ${response.statusText}\nResponse: ${text}`);
        throw new Error(`PATCH ${url} failed: ${response.status}`);
    }
    return response.json();
}

// Set active navigation link
function setActiveNavLink() {
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    console.log(`Set active nav for path: ${currentPath}`);
    const navLinks = document.querySelectorAll('#navbar a');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === 'categories.html' && (currentPath === 'categories.html' || currentPath === 'category-products.html')) {
            link.classList.add('active');
            console.log(`Set active: ${href}`);
        } else if (href === currentPath) {
            link.classList.add('active');
            console.log(`Set active: ${href}`);
        } else {
            link.classList.remove('active');
        }
    });
}

// Render products
function renderProducts(products, containerId) {
    console.log(`Rendering ${products.length} products to ${containerId}`, products);
    const container = document.getElementById(containerId) || document.querySelector(containerId);
    if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
    }

    container.innerHTML = products.map(product => `
        <div class="pro" onclick="window.location.href='singleproduct.html?id=${product._id}'">
            <img src="${product.image}" alt="${product.name}">
            <div class="des">
                <span>${product.brand}</span>
                <h5>${product.name}</h5>
                <div class="star">
                    ${'<i class="fas fa-star"></i>'.repeat(product.rating || 0)}
                </div>
                <h4>$${product.price}</h4>
            </div>
            <a href="#" class="add-to-cart" data-id="${product._id}"><i class="fas fa-shopping-cart cart"></i></a>
        </div>
    `).join('');
}

// Render admin products
function renderAdminProducts(products, containerId) {
    console.log(`Rendering ${products.length} admin products to ${containerId}`, products);
    const container = document.getElementById(containerId) || document.querySelector(containerId);
    if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
    }

    container.innerHTML = products.map(product => `
        <div class="admin-product">
            <span>${product.name}</span>
            <p>Brand: ${product.brand}, Price: $${product.price}, Featured: ${product.featured ? 'Yes' : 'No'}</p>
            <button class="edit-product" data-id="${product._id}">Edit</button>
            <button class="delete-product" data-id="${product._id}">Delete</button>
        </div>
    `).join('');
}

// Render admin categories
function renderAdminCategories(categories, containerId) {
    console.log(`Rendering ${categories.length} admin categories to ${containerId}`, categories);
    const container = document.getElementById(containerId) || document.querySelector(containerId);
    if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
    }

    container.innerHTML = categories.map(category => `
        <div class="admin-category">
            <span>${category.name}</span>
            <p>${category.description || 'No description'}</p>
            <button class="edit-category" data-id="${category._id}">Edit</button>
            <button class="delete-category" data-id="${category._id}">Delete</button>
        </div>
    `).join('');
}

// Populate category dropdown
function populateCategoryDropdown(categories, selectId) {
    console.log(`Populating ${categories.length} categories to ${selectId}`, categories);
    const select = document.getElementById(selectId) || document.querySelector(selectId);
    if (!select) {
        console.error(`Select ${selectId} not found`);
        return;
    }

    select.innerHTML = `<option value="">Select Category</option>` + categories.map(category => `
        <option value="${category._id}">${category.name}</option>
    `).join('');
}

// Render categories
async function renderCategories() {
    const categoriesContainer = document.getElementById('categories');
    if (!categoriesContainer) {
        console.warn('Categories container not found');
        return;
    }

    try {
        const categories = await get('/categories');
        console.log('Fetched categories:', categories);
        categoriesContainer.innerHTML = categories.map(category => `
            <a href="category-products.html?category=${category._id}" class="category-item">
                <div class="category-card">
                    <h4>${category.name}</h4>
                </div>
            </a>
        `).join('');
    } catch (err) {
        console.error('Error rendering categories:', err);
        categoriesContainer.innerHTML = '<p>Error loading categories. Please try again later.</p>';
        alert('Failed to load categories: ' + err.message);
    }
}

// Render products for a specific category in category-products.html
async function renderCategoryProducts() {
    const productsContainer = document.getElementById('products');
    const categoryNameHeader = document.getElementById('category-name');
    if (!productsContainer || !categoryNameHeader) {
        console.warn('Products container or category name header not found');
        return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const categoryId = urlParams.get('category');
    if (!categoryId) {
        productsContainer.innerHTML = '<p>No category specified.</p>';
        console.warn('No category ID in URL');
        return;
    }

    try {
        const category = await get(`/categories/${categoryId}`);
        console.log('Fetched category:', category);
        categoryNameHeader.textContent = category.name || 'Category Products';

        const products = await get(`/products?category=${categoryId}`);
        console.log('Fetched products:', products);
        renderProducts(products, 'products');

        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                addToCart(button.dataset.id);
            });
        });
    } catch (err) {
        console.error('Error rendering category products:', err);
        productsContainer.innerHTML = '<p>Error loading products. Please try again later.</p>';
        alert('Failed to load products: ' + err.message);
    }
}

// Render blogs
function renderBlogs(blogs, containerId) {
    console.log(`Rendering ${blogs.length} blogs to ${containerId}`, blogs);
    const container = document.getElementById(containerId) || document.querySelector(containerId);
    if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
    }

    container.innerHTML = blogs.map(blog => `
        <div class="blog-box">
            <div class="blog-img">
                <img src="${blog.image}" alt="${blog.title}">
            </div>
            <div class="blog-details">
                <h4>${blog.title}</h4>
                <p>${blog.description}</p>
                <a href="blogpost.html?id=${blog._id}">CONTINUE READING</a>
            </div>
            <h1>${new Date(blog.date).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' })}</h1>
        </div>
    `).join('');
}

// Render admin blogs
function renderAdminBlogs(blogs, containerId) {
    console.log(`Rendering ${blogs.length} admin blogs to ${containerId}`, blogs);
    const container = document.getElementById(containerId) || document.querySelector(containerId);
    if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
    }

    container.innerHTML = blogs.map(blog => `
        <div class="admin-blog">
            <span>${blog.title}</span>
            <p>${blog.description}</p>
            <button class="edit-blog" data-id="${blog._id}">Edit</button>
            <button class="delete-blog" data-id="${blog._id}">Delete</button>
        </div>
    `).join('');
}

// Render single blog post
function renderBlogPost(blog, containerId) {
    console.log(`Rendering blog post to ${containerId}`, blog);
    const container = document.getElementById(containerId) || document.querySelector(containerId);
    if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
    }

    container.innerHTML = `
        <h2>${blog.title}</h2>
        <img src="${blog.image}" alt="${blog.title}" class="blog-post-img">
        <p><strong>Date:</strong> ${new Date(blog.date).toLocaleDateString()}</p>
        <p>${blog.content || blog.description}</p>
    `;
}

// Fetch and render featured products
async function loadFeaturedProducts() {
    try {
        const products = await get('/products/featured?limit=8');
        renderProducts(products, 'featured-products');
    } catch (err) {
        console.error('Error loading featured products:', err);
        alert('Failed to load featured products. Please try again later.');
        document.getElementById('featured-products').innerHTML = '<p>Error loading featured products.</p>';
    }
}

// Fetch and render new arrivals with pagination
let newArrivalsPage = 1;
const newArrivalsLimit = 12;

async function loadNewArrivals(append = false) {
    try {
        const products = await get(`/products/new-arrivals?page=${newArrivalsPage}&limit=${newArrivalsLimit}`);
        console.log(`Fetched ${products.length} new arrivals, page: ${newArrivalsPage}`);
        if (append) {
            // Append new products
            const container = document.getElementById('new-arrivals');
            container.innerHTML += products.map(product => `
                <div class="pro" onclick="window.location.href='singleproduct.html?id=${product._id}'">
                    <img src="${product.image}" alt="${product.name}">
                    <div class="des">
                        <span>${product.brand}</span>
                        <h5>${product.name}</h5>
                        <div class="star">
                            ${'<i class="fas fa-star"></i>'.repeat(product.rating || 0)}
                        </div>
                        <h4>$${product.price}</h4>
                    </div>
                    <a href="#" class="add-to-cart" data-id="${product._id}"><i class="fas fa-shopping-cart cart"></i></a>
                </div>
            `).join('');
        } else {
            // Replace existing products
            renderProducts(products, 'new-arrivals');
        }
        // Hide "View More" if fewer products than limit (end of list)
        if (products.length < newArrivalsLimit) {
            const loadMoreButton = document.getElementById('load-more-new-arrivals');
            if (loadMoreButton) loadMoreButton.style.display = 'none';
        }
    } catch (err) {
        console.error('Error loading new arrivals:', err);
        alert('Failed to load new arrivals. Please try again later.');
        document.getElementById('new-arrivals').innerHTML = '<p>Error loading new arrivals.</p>';
    }
}

// Fetch and render all products
async function loadAllProducts(page = 1, limit = 16) {
    try {
        const products = await get(`/products?page=${page}&limit=${limit}`);
        renderProducts(products, 'all-products');
    } catch (err) {
        console.error('Error loading products:', err);
        alert('Failed to load products. Please try again later.');
        document.getElementById('all-products').innerHTML = '<p>Error loading products.</p>';
    }
}

// Fetch and render admin categories
async function loadAdminCategories() {
    try {
        const categories = await get('/categories');
        renderAdminCategories(categories, 'category-list');
        populateCategoryDropdown(categories, 'category-select');
    } catch (err) {
        console.error('Error loading admin categories:', err);
        alert('Failed to load categories: ' + err.message);
    }
}

// Fetch and render admin products
async function loadAdminProducts() {
    try {
        const products = await get('/products');
        renderAdminProducts(products, 'product-list');
    } catch (err) {
        console.error('Error loading admin products:', err);
        alert('Failed to load products: ' + err.message);
    }
}

// Fetch and render blogs
async function loadBlogs(page = 1, limit = 5) {
    try {
        const blogs = await get(`/blogs?page=${page}&limit=${limit}`);
        renderBlogs(blogs, 'blog-container');
    } catch (err) {
        console.error('Error loading blogs:', err);
        // alert('Failed to load blogs. Please try again later.');
        document.getElementById('blog-container').innerHTML = '<p>Error loading blogs.</p>';
    }
}

// Fetch and render single blog post
async function loadBlogPost() {
    const urlParams = new URLSearchParams(window.location.search);
    const blogId = urlParams.get('id');
    if (!blogId) return;

    try {
        const blog = await get(`/blogs/${blogId}`);
        renderBlogPost(blog, 'blog-post-container');
    } catch (err) {
        console.error('Error loading blog post:', err);
        // alert('Failed to load blog post: ' + err.message);
    }
}

// Fetch and render admin blogs
async function loadAdminBlogs() {
    try {
        const blogs = await get('/blogs');
        renderAdminBlogs(blogs, 'blog-list');
    } catch (err) {
        console.error('Error loading admin blogs:', err);
        // alert('Failed to load blogs: ' + err.message);
    }
}

// Fetch and render single product
async function loadSingleProduct() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    if (!productId) return;

    try {
        const product = await get(`/products/${productId}`);
        const mainImg = document.getElementById('MainImg');
        const smallImgs = document.getElementsByClassName('small-img');
        const details = document.querySelector('.single-pro-details');

        if (mainImg) mainImg.src = product.image;
        if (smallImgs.length) {
            Array.from(smallImgs).forEach(img => {
                img.src = product.image;
                img.onclick = () => { mainImg.src = img.src; };
            });
        }

        if (details) {
            details.innerHTML = `
                <h6>Home / ${product.category?.name || 'Product'}</h6>
                <h4>${product.name}</h4>
                <h2>$${product.price}</h2>
                <select>
                    <option>Select Size</option>
                    ${(product.sizes || []).map(size => `<option>${size}</option>`).join('')}
                </select>
                <input type="number" value="1" min="1" id="quantity">
                <button class="normal add-to-cart" data-id="${product._id}">Add to Cart</button>
                <h4>Product Details</h4>
                <span>${product.description || 'No description available'}</span>
            `;
        }
    } catch (err) {
        console.error('Error loading single product:', err);
        alert('Failed to load product: ' + err.message);
    }
}

// Fetch and render cart
async function loadCart() {
    try {
        const cart = await get('/cart');
        const tbody = document.querySelector('#cart tbody');
        if (!tbody) return;

        tbody.innerHTML = cart.items.map(item => `
            <tr>
                <td><a href="#" class="remove-item" data-id="${item.productId._id}"><i class="fas fa-times-circle" style="color:black"></i></a></td>
                <td><img src="${item.productId.image}" alt="${item.productId.name}"></td>
                <td>${item.productId.name}</td>
                <td>$${item.productId.price}</td>
                <td><input type="number" value="${item.quantity}" min="1" class="quantity-input" data-id="${item.productId._id}"></td>
                <td>$${(item.productId.price * item.quantity).toFixed(2)}</td>
            </tr>
        `).join('');

        const subtotal = document.querySelector('.subtotal table');
        if (subtotal) {
            subtotal.innerHTML = `
                <tr>
                    <td>Cart Subtotal</td>
                    <td>$${cart.totalPrice.toFixed(2)}</td>
                </tr>
                <tr>
                    <td>Shipping</td>
                    <td>Free</td>
                </tr>
                <tr>
                    <td><strong>Total</strong></td>
                    <td><strong>$${cart.totalPrice.toFixed(2)}</strong></td>
                </tr>
            `;
        }
    } catch (err) {
        console.error('Error loading cart:', err);
        alert('Failed to load cart: ' + err.message);
    }
}

// Handle registration
async function handleRegistration(event) {
    event.preventDefault();
    const form = event.target;

    const firstName = form.querySelector('#firstName')?.value;
    const lastName = form.querySelector('#lastName')?.value;
    const email = form.querySelector('#email')?.value;
    const password = form.querySelector('#password')?.value;
    const confirmPassword = form.querySelector('#confirmPassword')?.value;
    const phone = form.querySelector('#phone')?.value;
    const isAdmin = form.querySelector('#isAdmin')?.checked;

    if (!firstName || !email || !password) {
        alert('Required fields are missing!');
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    try {
        const response = await post('/users/register', {
            firstName,
            lastName,
            email,
            password,
            phone,
            isAdmin
        });

        if (response.token) {
            localStorage.setItem('jwtToken', response.token);
            alert('Registration successful! You are now logged in.');
            window.location.href = 'index.html';
        } else {
            alert('Registration successful! Please login with your credentials.');
            window.location.href = 'login.html';
        }
    } catch (err) {
        console.error('Error during registration:', err);
        alert('Registration failed: ' + err.message);
    }
}

// Handle login
async function handleLogin(event) {
    event.preventDefault();
    const form = event.target;
    const emailInput = form.querySelector('input[type="email"]');
    const passwordInput = form.querySelector('input[type="password"]');

    if (!emailInput || !passwordInput) {
        alert('Email or password input not found in login form');
        return;
    }

    const email = emailInput.value;
    const password = passwordInput.value;

    try {
        const response = await post('/users/login', { email, password });
        if (response.token) {
            localStorage.setItem('jwtToken', response.token);
            alert('Login successful!');
            const redirectUrl = localStorage.getItem('redirectAfterLogin') || 'index.html';
            localStorage.removeItem('redirectAfterLogin');
            window.location.href = redirectUrl;
        } else {
            alert('Login failed: No token received');
        }
    } catch (err) {
        console.error('Error logging in:', err);
        alert('Login failed: ' + err.message);
    }
}

// Handle add product form submission
async function handleAddProduct(event) {
    event.preventDefault();
    const form = event.target;

    console.log('Form inputs:', Array.from(form.querySelectorAll('input, textarea, select')).map(el => ({
        name: el.name,
        type: el.type,
        value: el.type === 'checkbox' ? el.checked : el.value
    })));

    const sizesInput = form.querySelector('input[name="sizes"]');
    const categorySelect = form.querySelector('select[name="category"]');

    if (!sizesInput || !categorySelect) {
        console.error('Missing form inputs:', {
            sizesInput: !!sizesInput,
            categorySelect: !!categorySelect
        });
        alert('Form is missing required inputs (sizes or category).');
        return;
    }

    const product = {
        name: form.querySelector('input[name="name"]').value,
        brand: form.querySelector('input[name="brand"]').value,
        price: parseFloat(form.querySelector('input[name="price"]').value),
        image: form.querySelector('input[name="image"]').value,
        rating: parseInt(form.querySelector('input[name="rating"]').value) || 0,
        description: form.querySelector('textarea[name="description"]').value,
        sizes: sizesInput.value ? sizesInput.value.split(',').map(s => s.trim()).filter(s => s) : [],
        featured: form.querySelector('input[name="featured"]').checked,
        category: categorySelect.value || null,
        stock: parseInt(form.querySelector('input[name="stock"]').value) || 0
    };

    console.log('Submitting product:', product);

    try {
        const response = await post('/products', product);
        alert('Product added successfully!');
        form.reset();
        loadAdminProducts();
    } catch (err) {
        console.error('Error adding product:', err);
        alert('Failed to add product: ' + err.message);
    }
}

// Handle add category form submission
async function handleAddCategory(event) {
    event.preventDefault();
    const form = event.target;
    const category = {
        name: form.querySelector('input[name="name"]').value,
        description: form.querySelector('textarea[name="description"]').value
    };

    console.log('Submitting category:', category);

    try {
        const response = await post('/categories', category);
        alert('Category added successfully!');
        form.reset();
        loadAdminCategories();
    } catch (err) {
        console.error('Error adding category:', err);
        alert('Failed to add category: ' + err.message);
    }
}

// Handle add blog form submission
async function handleAddBlog(event) {
    event.preventDefault();
    const form = event.target;
    const blog = {
        title: form.querySelector('input[name="title"]').value,
        description: form.querySelector('textarea[name="description"]').value,
        content: form.querySelector('textarea[name="content"]').value,
        image: form.querySelector('input[name="image"]').value,
        date: form.querySelector('input[name="date"]').value || new Date()
    };

    console.log('Submitting blog:', blog);

    try {
        const response = await post('/blogs', blog);
        alert('Blog post added successfully!');
        form.reset();
        loadAdminBlogs();
    } catch (err) {
        console.error('Error adding blog:', err);
        alert('Failed to add blog: ' + err.message);
    }
}

// Handle delete product
async function deleteProduct(productId) {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
        await del(`/products/${productId}`);
        alert('Product deleted successfully!');
        loadAdminProducts();
    } catch (err) {
        console.error('Error deleting product:', err);
        alert('Failed to delete product: ' + err.message);
    }
}

// Handle edit product
async function editProduct(productId) {
    try {
        const product = await get(`/products/${productId}`);
        const newName = prompt('Enter new name:', product.name);
        const newBrand = prompt('Enter new brand:', product.brand);
        const newPrice = prompt('Enter new price:', product.price);
        const newImage = prompt('Enter new image URL:', product.image);
        const newSizes = prompt('Enter new sizes (comma-separated):', product.sizes ? product.sizes.join(',') : '');
        const newFeatured = confirm('Is this a featured product?');

        if (newName && newName !== product.name) {
            await patch(`/products/${productId}`, {
                name: newName,
                brand: newBrand,
                price: parseFloat(newPrice),
                image: newImage,
                sizes: newSizes ? newSizes.split(',').map(s => s.trim()).filter(s => s) : [],
                featured: newFeatured
            });
            alert('Product updated successfully!');
            loadAdminProducts();
        }
    } catch (err) {
        console.error('Error editing product:', err);
        alert('Failed to edit product: ' + err.message);
    }
}

// Handle delete category
async function deleteCategory(categoryId) {
    if (!confirm('Are you sure you want to delete this category?')) return;

    try {
        await del(`/categories/${categoryId}`);
        alert('Category deleted successfully!');
        loadAdminCategories();
    } catch (err) {
        console.error('Error deleting category:', err);
        alert('Failed to delete category: ' + err.message);
    }
}

// Handle edit category
async function editCategory(categoryId) {
    try {
        const category = await get(`/categories/${categoryId}`);
        const newName = prompt('Enter new name:', category.name);
        const newDescription = prompt('Enter new description:', category.description || '');

        if (newName && newName !== category.name) {
            await patch(`/categories/${categoryId}`, { name: newName, description: newDescription });
            alert('Category updated successfully!');
            loadAdminCategories();
        }
    } catch (err) {
        console.error('Error editing category:', err);
        alert('Failed to edit category: ' + err.message);
    }
}

// Handle delete blog
async function deleteBlog(blogId) {
    if (!confirm('Are you sure you want to delete this blog post?')) return;

    try {
        await del(`/blogs/${blogId}`);
        alert('Blog post deleted successfully!');
        loadAdminBlogs();
    } catch (err) {
        console.error('Error deleting blog:', err);
        alert('Failed to delete blog: ' + err.message);
    }
}

// Handle edit blog
async function editBlog(blogId) {
    try {
        const blog = await get(`/blogs/${blogId}`);
        const newTitle = prompt('Enter new title:', blog.title);
        const newDescription = prompt('Enter new description:', blog.description);
        const newContent = prompt('Enter new content:', blog.content || '');
        const newImage = prompt('Enter new image URL:', blog.image);
        const newDate = prompt('Enter new date (YYYY-MM-DD):', blog.date.split('T')[0]);

        if (newTitle && newTitle !== blog.title) {
            await patch(`/blogs/${blogId}`, {
                title: newTitle,
                description: newDescription,
                content: newContent,
                image: newImage,
                date: newDate || blog.date
            });
            alert('Blog post updated successfully!');
            loadAdminBlogs();
        }
    } catch (err) {
        console.error('Error editing blog:', err);
        alert('Failed to edit blog: ' + err.message);
    }
}

// Add to cart
async function addToCart(productId, quantity = 1) {
    try {
        const response = await post('/cart/add', { productId, quantity });
        alert('Item added to cart!');
        if (window.location.pathname.includes('cart.html')) {
            loadCart();
        }
    } catch (err) {
        console.error('Error adding to cart:', err);
        alert('Failed to add item to cart: ' + err.message);
    }
}

// Remove from cart
async function removeFromCart(productId) {
    try {
        await del(`/cart/remove/${productId}`);
        loadCart();
    } catch (err) {
        console.error('Error removing from cart:', err);
        alert('Failed to remove item: ' + err.message);
    }
}

// Update cart quantity
async function updateCartQuantity(productId, quantity) {
    try {
        await patch(`/cart/update/${productId}`, { quantity });
        loadCart();
    } catch (err) {
        console.error('Error updating cart:', err);
        alert('Failed to update quantity: ' + err.message);
    }
}

// Handle newsletter signup
async function handleNewsletterSignup(event) {
    event.preventDefault();
    const form = event.target;
    const emailInput = form.querySelector('input[type="text"]');
    if (!emailInput) {
        alert('Email input not found in newsletter form');
        return;
    }
    const email = emailInput.value;

    try {
        await post('/newsletter/subscribe', { email });
        alert('Subscribed successfully!');
        form.reset();
    } catch (err) {
        console.error('Error subscribing:', err);
        alert('Failed to subscribe: ' + err.message);
    }
}

// Handle contact form submission
async function handleContactForm(event) {
    event.preventDefault();
    const form = event.target;

    let nameInput = form.querySelector('input[placeholder="Your Name"]');
    let emailInput = form.querySelector('input[placeholder="E-mail"]');
    let subjectInput = form.querySelector('input[placeholder="Subject"]');
    let messageInput = form.querySelector('textarea');

    if (!nameInput) nameInput = form.querySelector('input[name="name"]') || form.querySelector('#name');
    if (!emailInput) emailInput = form.querySelector('input[name="email"]') || form.querySelector('#email');
    if (!subjectInput) subjectInput = form.querySelector('input[name="subject"]') || form.querySelector('#subject');
    if (!messageInput) messageInput = form.querySelector('textarea[name="message"]') || form.querySelector('#message');

    console.log('Form inputs:', {
        nameInput: !!nameInput,
        emailInput: !!emailInput,
        subjectInput: !!subjectInput,
        messageInput: !!messageInput
    });

    if (!nameInput || !emailInput || !subjectInput || !messageInput) {
        alert('One or more contact form inputs are missing.');
        return;
    }

    const name = nameInput.value;
    const email = emailInput.value;
    const subject = subjectInput.value;
    const message = messageInput.value;

    try {
        await post('/contact/submit', { name, email, subject, message });
        alert('Message sent successfully!');
        form.reset();
    } catch (err) {
        console.error('Error sending message:', err);
        alert('Failed to send message: ' + err.message);
    }
}

// Handle checkout
async function handleCheckout(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const shippingDetails = {
        fullName: formData.get('fullName'),
        address: formData.get('address'),
        address2: formData.get('address2') || '',
        city: formData.get('city'),
        zipCode: formData.get('zipCode'),
        country: formData.get('country')
    };
    const phone = formData.get('phone');
    const email = formData.get('email') || 'guest@example.com';
    const paymentMethod = formData.get('paymentMethod');

    if (!shippingDetails.fullName || !shippingDetails.address || !shippingDetails.city || 
        !shippingDetails.zipCode || !shippingDetails.country || !phone || !paymentMethod) {
        alert('All shipping details, phone, and payment method are required.');
        return;
    }

    try {
        const cartResponse = await get('/cart');
        if (!cartResponse.items || cartResponse.items.length === 0) {
            alert('Your cart is empty');
            return;
        }

        const orderItems = cartResponse.items.map(item => ({
            quantity: item.quantity,
            product: item.productId._id
        }));

        const orderData = {
            shippingDetails,
            phone,
            email,
            orderItems,
            paymentMethod
        };

        console.log('Submitting order:', orderData);
        const token = localStorage.getItem('jwtToken');
        if (token) console.log('Token used:', token.slice(0, 10) + '...');

        const response = await post('/orders', orderData);
        alert(`Order placed successfully! Order ID: ${response.order.id}`);
        form.reset();
        window.location.href = 'index.html';

        await post('/cart/clear', {});
    } catch (err) {
        console.error('Error placing order:', err);
        alert(`Failed to place order: ${err.message}`);
    }
}

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    setActiveNavLink();

    const bar = document.getElementById('bar');
    const close = document.getElementById('close');
    const nav = document.getElementById('navbar');

    if (bar) {
        bar.addEventListener('click', () => {
            nav.classList.add('active');
            setActiveNavLink();
        });
    }

    if (close) {
        close.addEventListener('click', () => {
            nav.classList.remove('active');
        });
    }

    if (window.location.pathname.includes('admin.html')) {
        const token = localStorage.getItem('jwtToken');
        if (!token) {
            alert('Please log in as an admin to access this page.');
            localStorage.setItem('redirectAfterLogin', 'admin.html');
            window.location.href = 'login.html';
            return;
        }

        get('/users/me').then(user => {
            if (!user.isAdmin) {
                alert('Access denied. Admin privileges required.');
                window.location.href = 'index.html';
            } else {
                const addProductForm = document.getElementById('add-product-form');
                if (addProductForm) {
                    console.log('Binding add-product-form');
                    addProductForm.addEventListener('submit', handleAddProduct);
                } else {
                    console.warn('Add product form not found');
                }

                const addCategoryForm = document.getElementById('add-category-form');
                if (addCategoryForm) {
                    console.log('Binding add-category-form');
                    addCategoryForm.addEventListener('submit', handleAddCategory);
                } else {
                    console.warn('Add category form not found');
                }

                const addBlogForm = document.getElementById('add-blog-form');
                if (addBlogForm) {
                    console.log('Binding add-blog-form');
                    addBlogForm.addEventListener('submit', handleAddBlog);
                } else {
                    console.warn('Add blog form not found');
                }

                loadAdminProducts();
                loadAdminCategories();
                loadAdminBlogs();
            }
        }).catch(err => {
            console.error('Error verifying admin status:', err);
            alert('Failed to verify admin status. Please log in again.');
            localStorage.setItem('redirectAfterLogin', 'admin.html');
            localStorage.removeItem('jwtToken');
            window.location.href = 'login.html';
        });
    }

    if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
        loadFeaturedProducts();
        loadNewArrivals();
        // Add event listener for "View More" button
        const loadMoreButton = document.getElementById('load-more-new-arrivals');
        if (loadMoreButton) {
            loadMoreButton.addEventListener('click', () => {
                newArrivalsPage++;
                loadNewArrivals(true); // Append new products
            });
        }
    } else if (window.location.pathname.includes('shop.html')) {
        loadAllProducts();
    } else if (window.location.pathname.includes('singleproduct.html')) {
        loadSingleProduct();
    } else if (window.location.pathname.includes('cart.html')) {
        loadCart();
    } else if (window.location.pathname.includes('blog.html')) {
        loadBlogs();
    } else if (window.location.pathname.includes('blogpost.html')) {
        loadBlogPost();
    } else if (window.location.pathname.includes('categories.html')) {
        renderCategories();
    } else if (window.location.pathname.includes('category-products.html')) {
        renderCategoryProducts();
    } else if (window.location.pathname.includes('login.html')) {
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', handleLogin);
        }
    } else if (window.location.pathname.includes('register.html')) {
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', handleRegistration);
        }
    } else if (window.location.pathname.includes('checkout.html')) {
        const checkoutForm = document.getElementById('checkout-form');
        if (checkoutForm) {
            checkoutForm.addEventListener('submit', handleCheckout);
        }
    }

    const newsletterForms = document.querySelectorAll('#newsletter .form');
    newsletterForms.forEach(form => {
        form.addEventListener('submit', handleNewsletterSignup);
    });

    if (window.location.pathname.includes('contact.html')) {
        const contactForm = document.querySelector('#form-details form');
        if (contactForm) {
            contactForm.addEventListener('submit', handleContactForm);
            const submitButton = contactForm.querySelector('button');
            if (submitButton && !submitButton.type) {
                submitButton.type = 'submit';
            }
        }
    }

    document.addEventListener('click', (e) => {
        if (e.target.closest('.add-to-cart')) {
            e.preventDefault();
            const button = e.target.closest('.add-to-cart');
            const productId = button.dataset.id;
            const quantityInput = document.getElementById('quantity');
            const quantity = quantityInput ? parseInt(quantityInput.value) : 1;
            addToCart(productId, quantity);
        } else if (e.target.closest('.remove-item')) {
            e.preventDefault();
            const button = e.target.closest('.remove-item');
            const productId = button.dataset.id;
            removeFromCart(productId);
        } else if (e.target.classList.contains('delete-product')) {
            const productId = e.target.dataset.id;
            deleteProduct(productId);
        } else if (e.target.classList.contains('edit-product')) {
            const productId = e.target.dataset.id;
            editProduct(productId);
        } else if (e.target.classList.contains('delete-category')) {
            const categoryId = e.target.dataset.id;
            deleteCategory(categoryId);
        } else if (e.target.classList.contains('edit-category')) {
            const categoryId = e.target.dataset.id;
            editCategory(categoryId);
        } else if (e.target.classList.contains('delete-blog')) {
            const blogId = e.target.dataset.id;
            deleteBlog(blogId);
        } else if (e.target.classList.contains('edit-blog')) {
            const blogId = e.target.dataset.id;
            editBlog(blogId);
        }
    });

    document.addEventListener('change', (e) => {
        if (e.target.classList.contains('quantity-input')) {
            const input = e.target;
            const productId = input.dataset.id;
            const quantity = parseInt(input.value);
            if (quantity >= 1) {
                updateCartQuantity(productId, quantity);
            }
        }
    });
});
